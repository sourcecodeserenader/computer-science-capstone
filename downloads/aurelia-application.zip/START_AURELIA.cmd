@echo off
setlocal
cd /d "%~dp0Milestone4"
set "CS499_USERNAME=demo_admin"
set "CS499_PASSWORD=AureliaDemo2026"
if not exist "x64\Release\CS499_Milestone4_EnhancementThree_Databases.exe" (
  echo Please extract the entire ZIP before running the application.
  pause
  exit /b 1
)
start "" "x64\Release\CS499_Milestone4_EnhancementThree_Databases.exe"
