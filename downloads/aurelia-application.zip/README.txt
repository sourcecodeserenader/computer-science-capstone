AURELIA WEALTH STUDIO
Brianna Reed | CS 499 Milestone Four | Enhancement Three Databases
Built in Visual Studio 2022 with C++17 and WinSQLite

RUN THE SOFTWARE
1 Extract the entire ZIP to a folder on Windows 10 or Windows 11 x64
2 Double click START_AURELIA.cmd
3 Log in with username demo_admin and password AureliaDemo2026

Visual Studio is not required to launch the included Release x64 executable
Keep the extracted folders together; the launcher sets the database location and demonstration credentials

OPEN AND BUILD IN VISUAL STUDIO 2022
Open CS499_Milestone4_EnhancementThree.sln
Use Desktop development with C++, MSVC v143 and a Windows SDK
Select Debug and x64, then press F5
The project includes the working directory and demonstration login environment
The retained console implementation is excluded from x64 builds because the desktop has its own entry point

REVIEW THE APPLICATION
Welcome identifies Brianna Reed
Portfolio intelligence shows labeled charts calculated from stored fictional records
Client relationships contains 25 distinct clients with sortable columns and detailed profiles
Advisor ticket desk separates High/Urgent, Medium/Low and Completed tasks
Click ticket headers to sort, scroll horizontally for all fields, and hover for full details
Review goals, Data integrity and Governance log
Generate enterprise and individual PDF reports and Excel workbooks through Reports and exports
Make a copy of the extracted folder before testing changes if preserving the supplied baseline

FILES
Milestones1_2_3 contains the three earlier source artifacts, unchanged
Milestone4 contains the current source, project, schema, populated database and executable
Reports can be generated inside the software; test files and build caches are omitted
Submit the required Word narrative separately

VERIFIED
Debug x64 and Release x64 builds passed with 0 errors and 24 nonfatal conversion warnings
The included Release executable passed login, the 25 client directory check and all three ticket lanes
Earlier database workflow and ticket/client tests passed 111 and 298 assertions
All 26 PDFs, 26 workbooks and 52 native Excel charts were validated
This is fictional capstone modeling; dated public market observations are separate from portfolio prices and there is no connected live feed
